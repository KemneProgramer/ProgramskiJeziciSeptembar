package com.nemanjamarjanovic.ispitpj.repository;


import com.nemanjamarjanovic.ispitpj.entity.Tim;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TimRepository extends JpaRepository<Tim, Integer> {
}
