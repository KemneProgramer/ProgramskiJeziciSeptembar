package com.nemanjamarjanovic.ispitpj.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Table(name = "osoblje")
public class Osoblje {

    @Setter
    @Getter
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer osoblje_id;

    @Setter
    @Getter
    @ManyToOne
    @JoinColumn(name = "tim_id", nullable = false)
    private Tim tim;

    @Setter
    @Getter
    @Enumerated(EnumType.STRING)
    @Column(name = "duznost", nullable = false)
    private Duznost duznost;

    @Setter
    @Getter
    @Column(name = "is_zaposlen", nullable = false)
    private Integer is_zaposlen;


    @Setter
    @Getter
    @Column(name = "ime", nullable = false)
    private String ime;

    @Setter
    @Getter
    @Column(name = "prezime", nullable = false)
    private String prezime;





    public enum Duznost {
        Trener,
        Terapeut,
        Lekar

    }


}