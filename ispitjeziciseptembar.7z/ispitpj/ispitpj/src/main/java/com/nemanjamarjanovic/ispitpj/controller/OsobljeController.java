package com.nemanjamarjanovic.ispitpj.controller;

import com.nemanjamarjanovic.ispitpj.entity.Osoblje;
import com.nemanjamarjanovic.ispitpj.service.OsobljeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/osoblje")
@RequiredArgsConstructor
@CrossOrigin
public class OsobljeController {

    private final OsobljeService staffService;


    @GetMapping
    public ResponseEntity<List<Osoblje>> getAllStaff() {
        List<Osoblje> staffList = staffService.getAllStaff();
        if (staffList.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(staffList, HttpStatus.OK);
    }


    @PostMapping
    public ResponseEntity<Osoblje> createStaff(@RequestBody Osoblje staff) {
        try {
            Osoblje savedStaff = staffService.saveStaff(staff);
            return new ResponseEntity<>(savedStaff, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteStaff(@PathVariable Integer id) {
        try {
            staffService.deleteStaff(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/by-team-name")
    public ResponseEntity<List<Osoblje>> getStaffByTeamName(@RequestParam("imetima") String imetima) {
        List<Osoblje> staffList = staffService.getStaffByTeamName(imetima);
        if (staffList.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(staffList, HttpStatus.OK);
    }

}




