package com.nemanjamarjanovic.ispitpj.service;

import com.nemanjamarjanovic.ispitpj.entity.Osoblje;

import com.nemanjamarjanovic.ispitpj.repository.OsobljeRepository;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OsobljeService {

    private final OsobljeRepository osobljeRepository;

    public List<Osoblje> getAllStaff() {
        return osobljeRepository.findAll();
    }

    public Osoblje saveStaff(Osoblje staff) {
        return osobljeRepository.save(staff);
    }

    public void deleteStaff(Integer id) {
        osobljeRepository.deleteById(id);
    }

    public List<Osoblje> getStaffByTeamName(String imetima) {
        return osobljeRepository.findByTim_Imetima(imetima);
    }

}