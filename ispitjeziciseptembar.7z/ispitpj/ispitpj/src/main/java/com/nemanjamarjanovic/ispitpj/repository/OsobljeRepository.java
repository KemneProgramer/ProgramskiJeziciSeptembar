package com.nemanjamarjanovic.ispitpj.repository;

import com.nemanjamarjanovic.ispitpj.entity.Osoblje;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OsobljeRepository extends JpaRepository<Osoblje, Integer> {
    List<Osoblje> findByTim_Imetima(String imetima);


}